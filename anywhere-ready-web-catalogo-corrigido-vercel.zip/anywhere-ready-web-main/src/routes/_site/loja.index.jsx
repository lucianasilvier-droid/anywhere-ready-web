import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight, ShoppingBag, ShieldCheck, Zap, Nfc } from "lucide-react";

export const Route = createFileRoute("/_site/loja/")({
  head: () => ({
    meta: [
      { title: "Catálogo — Google NFC Connect" },
      {
        name: "description",
        content: "Conheça as placas NFC e serviços Google Maps. Compra segura pelo checkout InfinitePay.",
      },
    ],
  }),
  component: LojaPage,
});

// Catálogo comercial fixo: cada item usa a arte original do projeto e seu checkout
// InfinitePay próprio. Não depende de produtos cadastrados no banco para aparecer.
const PRODUTOS = [
  {
    id: "kit-google-instagram",
    nome: "Kit Placas NFC Google + Instagram",
    descricao: "Duas placas em acrílico com NFC: uma para avaliações no Google e outra para seu Instagram.",
    imagem: "/images/divulgacao/arte-2026-10-31-a.jpeg",
    checkout: "https://loja.infinitepay.io/bikercourierexpress/vhh6927-kit-google-e-instagram",
    destaque: true,
  },
  {
    id: "placa-instagram-nfc",
    nome: "Placa NFC Instagram",
    descricao: "Display em acrílico para seus clientes aproximarem o celular e acessarem seu Instagram.",
    imagem: "/images/divulgacao/displays-instagram-acrilico-neon.png",
    checkout: "https://loja.infinitepay.io/bikercourierexpress/xpg6030-placas-nfc-instagram",
  },
  {
    id: "placa-google-nfc",
    nome: "Placa Google NFC",
    descricao: "Placa de avaliação do Google com NFC: facilite o acesso dos clientes à página de avaliações da sua empresa.",
    imagem: "/images/divulgacao/placa-nfc-avaliacao-google.jpeg",
    checkout: "https://loja.infinitepay.io/bikercourierexpress/hhy2911-placa-google-nfc",
  },
  {
    id: "empresa-google-maps",
    nome: "Sua Empresa no Google Maps",
    descricao: "Serviço para colocar sua empresa no Google Maps e facilitar que clientes encontrem seu negócio.",
    imagem: "/images/divulgacao/google-maps-perfil-empresa.jpeg",
    checkout: "https://loja.infinitepay.io/bikercourierexpress/wmk4399-sua-empresa-no-google-maps",
  },
];

function LojaPage() {
  return (
    <div>
      <section className="relative overflow-hidden border-b border-white/[0.06]">
        <div className="aurora absolute inset-0" />
        <div className="relative mx-auto w-full max-w-7xl px-4 py-14 sm:px-6">
          <p className="text-[11px] font-bold uppercase tracking-[0.24em] text-primary/80">Loja oficial</p>
          <h1 className="mt-3 max-w-2xl font-heading text-[2.1rem] font-extrabold leading-tight text-white sm:text-[2.8rem]">
            Catálogo de placas NFC e serviços
          </h1>
          <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-white/60">
            Escolha o produto desejado e finalize sua compra diretamente pelo checkout seguro da InfinitePay.
          </p>
          <div className="mt-7 grid gap-3 sm:grid-cols-3">
            {[
              { icon: Nfc, titulo: "Tecnologia NFC", texto: "Acesso por aproximação do celular." },
              { icon: Zap, titulo: "Compra simples", texto: "Cada produto tem seu próprio checkout." },
              { icon: ShieldCheck, titulo: "Checkout seguro", texto: "Pagamento processado pela InfinitePay." },
            ].map((item) => (
              <div key={item.titulo} className="flex items-start gap-3 rounded-xl border border-white/[0.08] bg-white/[0.03] p-4">
                <item.icon className="mt-0.5 h-4.5 w-4.5 text-primary" />
                <div>
                  <p className="text-[13px] font-semibold text-white">{item.titulo}</p>
                  <p className="text-[11.5px] leading-relaxed text-white/45">{item.texto}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto w-full max-w-7xl px-4 py-12 sm:px-6">
        <div className="mb-6 flex items-center gap-2">
          <ShoppingBag className="h-4.5 w-4.5 text-primary" />
          <h2 className="font-heading text-lg font-bold text-white">Catálogo</h2>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {PRODUTOS.map((produto) => (
            <article key={produto.id} className="group flex flex-col overflow-hidden rounded-2xl border border-white/[0.08] bg-white/[0.03] transition-all hover:-translate-y-1 hover:border-primary/30">
              <div className="relative bg-white/[0.04] p-3">
                <img
                  src={produto.imagem}
                  alt={produto.nome}
                  loading="lazy"
                  className="h-64 w-full rounded-xl object-contain"
                />
                {produto.destaque && (
                  <span className="absolute left-5 top-5 rounded-full bg-primary px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[#0a1128]">
                    Kit completo
                  </span>
                )}
              </div>
              <div className="flex flex-1 flex-col p-5">
                <h3 className="font-heading text-[15px] font-bold leading-snug text-white">{produto.nome}</h3>
                <p className="mt-2 flex-1 text-[12.5px] leading-relaxed text-white/55">{produto.descricao}</p>
                <a
                  href={produto.checkout}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-5 inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-extrabold text-[#0a1128] transition hover:brightness-110"
                >
                  Comprar agora <ArrowUpRight className="h-4 w-4" />
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
